//
//  ViewController.m
//  RunTimeDynamic
//
//  Created by Alan on 2018/5/14.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import "ViewController.h"
#import <objc/runtime.h>


@interface Person: NSObject

@end

@implementation Person
/**
 可以看到我们通过forwardingTargetForSelector把当前ViewController的方法转发给了Person去执行了。打印结果也证明我们成功实现了转发。
 */
- (void)run {
    NSLog(@"Person Doing run");//Person的run函数
}
@end

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //执行run函数
    [self performSelector:@selector(run)];
    // Do any additional setup after loading the view, typically from a nib.
}

+(BOOL)resolveInstanceMethod:(SEL)sel
{
//    if (sel == @selector(run)) {//如果是执行run函数，就动态解析，指定新的IMP
//        class_addMethod([self class], sel, (IMP)runMethod, "v@:");
//        return YES;
//    }
//    return [super resolveInstanceMethod:sel];
//
//   /*
//    可以看到虽然没有实现run:这个函数，但是我们通过class_addMethod动态添加fooMethod函数，并执行runMethod这个函数的IMP。从打印结果看，成功实现了。
//
//    如果resolve方法返回 NO ，运行时就会移到下一步：forwardingTargetForSelector。
//    */
    return YES;//返回YES，进入下一步转发

}
void runMethod(id obj, SEL _cmd) {
    NSLog(@"runMethod run");//新的run函数
}
/*
 如果目标对象实现了-forwardingTargetForSelector:，Runtime 这时就会调用这个方法，给你把这个消息转发给其他对象的机会。
 */

- (id)forwardingTargetForSelector:(SEL)aSelector {
    SEL sel = @selector(run);
//    if (aSelector == @selector(run)) {
//        return [Person new];//返回Person对象，让Person对象接收这个消息
//    }
//
//    return [super forwardingTargetForSelector:aSelector];
//
    
    return nil;//返回nil，进入下一步转发
}
- (NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector {
    if ([NSStringFromSelector(aSelector) isEqualToString:@"run"]) {
        return [NSMethodSignature signatureWithObjCTypes:"v@:"];//签名，进入forwardInvocation
    }
    
    return [super methodSignatureForSelector:aSelector];
}

- (void)forwardInvocation:(NSInvocation *)anInvocation {
    SEL sel = anInvocation.selector;
    
    Person *p = [Person new];
    if([p respondsToSelector:sel]) {
        [anInvocation invokeWithTarget:p];
    }
    else {
        [self doesNotRecognizeSelector:sel];
    }
    /**
     我们实现了完整的转发。通过签名，Runtime生成了一个对象anInvocation，发送给了forwardInvocation，我们在forwardInvocation方法里面让Person对象去执行了run函数。签名参数v@:怎么解释呢，这里苹果文档Type Encodings有详细的解释https://developer.apple.com/library/content/documentation/Cocoa/Conceptual/ObjCRuntimeGuide/Articles/ocrtTypeEncodings.html#//apple_ref/doc/uid/TP40008048-CH100-SW1。
*/
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
