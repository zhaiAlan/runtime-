//
//  NSObject+AlanKVO.h
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (AlanKVO)
- (void)alan_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath options:(NSKeyValueObservingOptions)options context:(void *)context;

- (void)Alan_observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context;

@end
