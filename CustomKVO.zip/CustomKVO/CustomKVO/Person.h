//
//  Person.h
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    @public
    NSString *_sex;
    
}
@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger age;
@end
