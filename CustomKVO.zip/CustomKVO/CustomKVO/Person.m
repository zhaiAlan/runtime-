//
//  Person.m
//  CustomKVO
//
//  Created by Alan on 2018/4/25.
//  Copyright © 2018年 zhaixingzhi. All rights reserved.
//

#import "Person.h"

@implementation Person
- (void)setName:(NSString *)name{
    _name = name;
}

@end
